#include <avr/interrupt.h>
#include "avr/io.h"
#include "avr/pgmspace.h"
#include "avr/wdt.h"
#include "7seg_table.h"

// ������� ��
#define F_CPU 8000000UL
#include "util/delay.h"

//������� ��� ������� � �������� � �������� ������
#define Lo(x)   ((x) & 0xFF) 
#define Hi(x)   (((x)>>8) & 0xFF) 

//��� 1-wire
#define OW_DDR DDRD
#define OW_READ PIND
#define OW_PIN 2

//�������
#define READ_ROM 0x33
#define MATCH_ROM 0x55
#define SKIP_ROM 0xCC

#define READ_MEM 0xBE
#define CONVERT_T 0x44

#define MAX_TEMP 99UL

unsigned char rom_cmd;
unsigned char cmd;
unsigned char tmp_count;
unsigned char tmp8;

const unsigned char ROM[7]= {0x28,0,0,0,0,0,0};
volatile unsigned char RECV_ROM[8];
unsigned char MEM[8] __attribute__ ((section (".noinit")));

volatile int current_temp __attribute__ ((section (".noinit")));
unsigned int tmp16;
unsigned char tmp8;

unsigned char display[3] = {255,255,255};
unsigned char display_pos=0;

//���������, �����
volatile unsigned char crc_table[256] PROGMEM  = {
 0, 94, 188, 226, 97, 63, 221, 131, 194, 156, 126, 32, 163, 253, 31, 65,
 157, 195, 33, 127, 252, 162, 64, 30, 95, 1, 227, 189, 62, 96, 130, 220,
 35, 125, 159, 193, 66, 28, 254, 160, 225, 191, 93, 3, 128, 222, 60, 98,
 190, 224, 2, 92, 223, 129, 99, 61, 124, 34, 192, 158, 29, 67, 161, 255,
 70, 24, 250, 164, 39, 121, 155, 197, 132, 218, 56, 102, 229, 187, 89, 7,
 219, 133, 103, 57, 186, 228, 6, 88, 25, 71, 165, 251, 120, 38, 196, 154,
 101, 59, 217, 135, 4, 90, 184, 230, 167, 249, 27, 69, 198, 152, 122, 36,
 248, 166, 68, 26, 153, 199, 37, 123, 58, 100, 134, 216, 91, 5, 231, 185,
 140, 210, 48, 110, 237, 179, 81, 15, 78, 16, 242, 172, 47, 113, 147, 205,
 17, 79, 173, 243, 112, 46, 204, 146, 211, 141, 111, 49, 178, 236, 14, 80,
 175, 241, 19, 77, 206, 144, 114, 44, 109, 51, 209, 143, 12, 82, 176, 238,
 50, 108, 142, 208, 83, 13, 239, 177, 240, 174, 76, 18, 145, 207, 45, 115,
 202, 148, 118, 40, 171, 245, 23, 73, 8, 86, 180, 234, 105, 55, 213, 139,
 87, 9, 235, 181, 54, 104, 138, 212, 149, 203, 41, 119, 244, 170, 72, 22,
 233, 183, 85, 11, 136, 214, 52, 106, 43, 117, 151, 201, 74, 20, 246, 168,
 116, 42, 200, 150, 21, 75, 169, 247, 182, 232, 10, 84, 215, 137, 107, 53};

unsigned char CRC;

void RefreshTemp()
{
 char set_bit;

 set_bit=0;
 if ((TIMSK & (1<<TOIE1))!=0) set_bit=1;
 TIMSK &= ~(1<<TOIE1);


 DDRD |= (1<<DDD3);
 PORTD |= (1<<PORTD3);

 _delay_ms(1);

 TCNT0 = 0;
 TIFR |= 1<<TOV0; //����� ����� TOV0
 TIMSK &= ~(1<<TOIE0);
 TCCR0B = 4; // 8M/256

 DDRD &= ~(1<<DDD3);
 PORTD &= ~(1<<PORTD3);

 while ((PIND & (1<<PIND3))!=0);

 TCCR0B = 0; 

 DDRD |= (1<<DDD3);
 PORTD &= ~(1<<PORTD3);

 if(TCNT0<16) TCNT0 = 16;
 current_temp = (TCNT0 - 16UL)*((MAX_TEMP*16UL)/152UL);
 current_temp -= current_temp % 16;
 MEM[0] = Lo(current_temp);
 MEM[1] = Hi(current_temp);

 PORTB = 0;

 if (set_bit) TIMSK |= (1<<TOIE1);
};

inline void ow_up()
{
 OW_DDR &= ~(1<<OW_PIN);
};

inline void ow_down()
{
 OW_DDR |= (1<<OW_PIN);
};

inline void wait4low()
{
 while ((OW_READ & (1<<OW_PIN))!=0);
};

inline void wait4high()
{
 while ((OW_READ & (1<<OW_PIN))==0);
};


unsigned char Read_byte()
{
 unsigned char tmp_count;
 unsigned char tmp_value=0;

 wait4high();

 for (tmp_count=0; tmp_count<8; tmp_count++)
 {
  wait4low();
  _delay_us(15);
  
  tmp_value = tmp_value >> 1;
  if ((OW_READ & (1<<OW_PIN))!=0) tmp_value |= 0x80;
  wait4high();
 };

 return tmp_value;
};

void Send_byte(unsigned char _data)
{
 unsigned char tmp_count;

 wait4high();

 for (tmp_count=0; tmp_count<8; tmp_count++)
 {
  wait4low();
  if ((_data & 1)==0) ow_down();
  _data = _data >> 1;
  _delay_us(60);
  ow_up();
  wait4high();
 };
};


void Phase2()
{
  cmd=Read_byte();
  if (cmd==READ_MEM)
  {
   CRC=0;
   for (tmp_count=0; tmp_count<8; tmp_count++)
    {
    Send_byte(MEM[tmp_count]);
	CRC = pgm_read_byte(&(crc_table[CRC ^ MEM[tmp_count]]));
	};
   Send_byte(CRC);
  };

  //���� ����� � ����� �������� ��������� ������ ������, �� ��� ����
};

void one_wire_action()
{
 wdt_enable(WDTO_500MS);
 TIMSK &= ~(1<<TOIE1);
 sei();
 
 //Presence
 wait4high();
 _delay_us(30);
 ow_down();
 _delay_us(100);
 ow_up();
 wait4high();

 rom_cmd=Read_byte();
 if (rom_cmd==SKIP_ROM)
 {
  Phase2();
 };

 if (rom_cmd==MATCH_ROM)
 {
  tmp8=0;
  for (tmp_count=0; tmp_count<8; tmp_count++) 
   if (Read_byte()==ROM[tmp_count]) 
    tmp8++;
  if (tmp8==8) Phase2();
 };

  if (rom_cmd==READ_ROM)
  {
   CRC=0;
   for (tmp_count=0; tmp_count<7; tmp_count++)
    {
    Send_byte(ROM[tmp_count]);
	CRC = pgm_read_byte(&(crc_table[CRC ^ ROM[tmp_count]]));
	};
   Send_byte(CRC);
  };
 
 TIMSK |= (1<<TOIE1);

 WDTCSR = 24;
 WDTCSR = 0;
};


ISR (INT0_vect)
{
  if ((MCUCR & (1<<ISC00))!=0) 
   {
    TCCR0B = 0; //��������� ������
	TIFR |= 1<<TOV0;
	MCUCR = (1<<ISC01); //����� ISC00 - ���������� �� \__
    return;
   }

  TCNT0 = 255-50;
  TIFR |= 1<<TOV0; //����� ����� TOV0
  TIMSK |= (1<<TOIE0);
  MCUCR = (1<<ISC01)|(1<<ISC00); // ���������� �� __/
  TCCR0B = 3; //�������� �� 64
};

ISR (TIMER0_OVF_vect)
{
  TCCR0B = 0;
  TIFR |= 1<<TOV0;
  one_wire_action();
};


ISR (TIMER1_OVF_vect)
{
   PORTD &= ~((1<<PORTD6)|(1<<PORTD5)|(1<<PORTD4));
   display_pos++;
   if (display_pos>2) display_pos = 0;
   PORTB = display[display_pos];
   switch (display_pos) {
   case 0: PORTD |= (1<<PORTD4); break;
   case 1: PORTD |= (1<<PORTD5); break;
   case 2: PORTD |= (1<<PORTD6); break;
   };

   wdt_reset();
};

void main()
{
 wdt_reset();
 WDTCSR = 24;
 WDTCSR = 0;
 OW_DDR &= ~(1<<OW_PIN);
 DDRB = (1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<4)|(1<<6)|(1<<7);
 PORTB = ClearDisplay;

 PORTD |= (1<<0)|(1<<1);
 
 MEM[2] = 0;
 MEM[3] = 0;
 MEM[4] = 0;
 MEM[5] = 0xFF;
 MEM[6] = 0;
 MEM[7] = 0x10;

 DDRD |= (1<<DDD4) | (1<<DDD6) | (1<<DDD5);
 PORTD &= ~(1<<PORTD3);

 TIFR |= 1<<TOV0;
 EIFR |= 1<<INTF0;
 MCUCR = (1<<ISC01); //����� ISC00 - ���������� �� \__
 GIMSK |= (1<<INT0); 

 TCCR1B = 1;
 TIMSK |= (1<<TOIE1);

 sei();

 while(1)
 {
  if (!(PIND & (1<<0))) current_temp += 1;
  if (!(PIND & (1<<1))) current_temp -= 1;


  if (current_temp > 99) current_temp = 99;
  if (current_temp < -55) current_temp = -55;

  if (current_temp >= 0)
  {
   MEM[0] = Lo(current_temp*16);
   MEM[1] = Hi(current_temp*16);
  }
  else
  {
   MEM[0] = Lo(current_temp*16);
   MEM[1] = Hi(current_temp*16) | 0xF8;
  }

  if (current_temp<0)
   {
   tmp16 = abs(current_temp);
   display[0] = 1<<segment_G;
   }
  else
   {
   tmp16 = current_temp;
   display[0] = ClearDisplay;
   }


  display[2] = numbers[tmp16 % 10];

  if (tmp16>9) 
   display[1] = numbers[tmp16 / 10];
  else
   {
    display[1]=ClearDisplay;
    if (current_temp<0)
     {
	  display[1] = numbers[tmp16 % 10];
      display[2] = ClearDisplay;
	 }
   }
  _delay_ms(100);
 };
};
